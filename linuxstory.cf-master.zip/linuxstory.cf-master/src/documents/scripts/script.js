
(function(){
    $("body").hide().fadeIn(1000);
})();
