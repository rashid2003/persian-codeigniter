justforfun
==========

فقط برای تفریح - داستان یک انقلابی اتفاقی: لینوس توروالدز



# todo

- [ ] order the articles
- [ ] add donation page

